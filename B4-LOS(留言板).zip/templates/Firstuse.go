package main

import (
	"fmt"
	"github.com/jinzhu/gorm"
)
import  _"github.com/jinzhu/gorm/dialects/mysql"

type reply struct {
	gorm.Model
	Replyer string
	Context string
	Bereplypostid uint
}

type UsersDate struct {//用户数据
	gorm.Model
	UserName string
	PassWord string
	Onion int64
}

type Postdate struct {
	gorm.Model
	Owner string
	Postcontext string
}
func main()  {
	db , err := gorm.Open("mysql" , "root:password@(127.0.0.1:3306)/zhihu?charset=utf8mb4&parseTime=True&loc=Local")
	defer db.Close()
	if err != nil{
		panic(err)
	}
	db.AutoMigrate(&Postdate{})
	db.AutoMigrate(&UsersDate{})
	db.AutoMigrate(&reply{})
	var post01 Postdate
	var admin UsersDate
	var replyx reply
	admin.UserName = "admin"
	admin.PassWord = "000000"
	post01.Owner = admin.UserName
	post01.Postcontext = "欢迎来到LOS博客，这是我们的第一条帖子"
	replyx.Bereplypostid = 1
	replyx.Replyer = admin.UserName
	replyx.Context = "这是第一个评论"
	db.Create(&post01)
	db.Create(&admin)
	db.Create(&replyx)
	fmt.Println(post01)
}

