package main

import (
	"fmt"
	"github.com/jinzhu/gorm"
)


type UserId struct {
	name string
	password string
}

type replyer struct {
	replyuser string
	replypostid uint
}

type PosterandPost struct {
	name string
	connect string
}

func CountAny(in interface{}) int {//计算目前用户个数和发帖总数
	var count int
	db := Connectsql()
	defer db.Close()
	switch t := in.(type) {
	case UsersDate:
		db.Model(&t).Where("id > ?" , 0).Count(&count)
	case Postdate:
		db.Model(&t).Where("id > ?" , 0).Count(&count)
	}

	return count
}

func Repeatif(UserNamein string) bool {//从数据库中检查用户名是否重复
	db := Connectsql()
	defer db.Close()
	ok := true
	var count int
	db.Model(&UsersDate{}).Where("id > ?" , 0).Count(&count)
	fmt.Println(count)
	for i:=1; i<=count;i++{
		var user UsersDate
		db.Table("users_dates").Where("id = ?" , i).First(&user)
		if user.UserName == UserNamein{
			ok = false
			break
		}
	}
	return ok
}

func Connectsql() (db *gorm.DB) {//连接数据库（注：调用一次此函数就要关闭一次）
	db , err := gorm.Open("mysql" , "root:password@(127.0.0.1:3306)/zhihu?charset=utf8mb4&parseTime=True&loc=Local")
	if err != nil{
		panic(err)
	}
	db.AutoMigrate(&UsersDate{})
	return db
}

func (userx UsersDate) putdatabase(in interface{}) {//使用此前确保用户已经安全，此函数实现了
	db := Connectsql()
	defer db.Close()
	ok := Repeatif(userx.UserName)
	if ok {
		db.Create(&userx)
	} else {
		switch t := in.(type) {//in是int则是改变前面的onion值（1是登录，0是不在线）
		case int:
			db.Model(&userx).Where("user_name = ?" , userx.UserName).Update("onion" , t)
		case UsersDate://in是usersdate时就整个修改可改用户名和密码
			db.Model(&userx).Where("user_name = ?" , userx.UserName).Updates(t)
		case PosterandPost://如果是包含了发帖人用户名和帖子内容的posterandpost类型的结构体，就将内容给postdate并创建帖子
			var postx Postdate
			postx.Owner = t.name
			postx.Postcontext = t.connect
			db.Create(&postx)
		case reply://同上
			var replyx reply
			replyx.Replyer = t.Replyer
			replyx.Bereplypostid = t.Bereplypostid
			replyx.Context = t.Context
			db.Create(&replyx)
		}
	}

}

func Autoreaduser(userna string) UsersDate {//根据用户名匹配用户信息
	db := Connectsql()
	defer db.Close()
	var userda UsersDate
	db.Table("users_dates").Where("user_name = ?" , userna).First(&userda)
	return userda
}

func Autoreanpost(postid int) Postdate {//根据帖子id匹配帖子
	db := Connectsql()
	defer db.Close()
	var postda Postdate
	db.Table("postdates").Where("id = ?" , postid).First(&postda)
	return postda
}

func Autofindreply(postid int) (replys []reply , count int){//根据帖子找回复
	db :=Connectsql()
	defer db.Close()
	db.Table("replies").Where("bereplypostid = ?" , postid).Count(&count).Find(&replys)
	return
}

func (userna UserId) readdatabase() UsersDate {//目前实现了接入用户名和密码判断密码是否正确和返回用户的整个数据
	db := Connectsql()
	var userda UsersDate
	defer db.Close()
	db.Table("users_dates").Where("user_name = ?" , userna.name).First(&userda)
	if userna.password != userda.PassWord {
		userda = UsersDate{}
	}
	return userda
}

func (userda UsersDate)Onionif() (ok bool) {
	if userda.Onion == 1{
		 ok = true
	} else {
		ok = false
	}
	return
}