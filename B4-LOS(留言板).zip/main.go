package main

import (
	"fmt"
	"strconv"

	//fuzz "github.com/google/gofuzz"
	"github.com/jinzhu/gorm"
	//"time"
)
import  _"github.com/jinzhu/gorm/dialects/mysql"
import "github.com/gin-gonic/gin"

type databasess interface {
	readdatabase() UsersDate
	putdatabase()
}


type reply struct {
	gorm.Model
	Replyer string
	Context string
	Bereplypostid uint
}

type UsersDate struct {//用户数据
	gorm.Model
	UserName string
	PassWord string
	Onion int64
}

type Postdate struct {
	gorm.Model
	Owner string
	Postcontext string

}

func Register(c *gin.Context)  {//实现注册
	fmt.Println(c.FullPath())
	var registerx UsersDate
	registerx.UserName = c.PostForm("UserName")
	registerx.PassWord = c.PostForm("PassWord")
	ok := Repeatif(registerx.UserName)
	//ok := true
	if ok {
		c.JSON(200 , gin.H{
			"your username is" : registerx.UserName,
			"注册状态" : "成功",
		})
		registerx.putdatabase("Onion")
	}else {
		c.JSON(200 , gin.H{
			"这次状态" : "注册失败",
		})
	}
	fmt.Println("Hello")
}

func  login(c *gin.Context)  {//实现登录
		var registerx UsersDate
		registerx.UserName = c.PostForm("UserName")
		registerx.PassWord = c.PostForm("PassWord")
		userid := UserId{name:registerx.UserName, password:registerx.PassWord}
		userfromdb := userid.readdatabase()
		if userfromdb.ID != 0  {//登陆成功
			userfromdb.Onion = 1
			userfromdb.putdatabase(1)
			//time.Sleep(time.Second * 2)
			//c.Request.URL.Path = "zhihu/home" + registerx.UserName
			c.Redirect(302 , "http://127.0.0.1:8090/zhihu/home/" + registerx.UserName)
		}else {
			c.HTML(200, "loginerror.html" ,gin.H{
				"what" : "登陆",
			})
		}
}

func main()  {
	r := gin.Default()
	//r.LoadHTMLGlob("templates/*")
	r.LoadHTMLGlob("templates/**/*" )
	r.GET("zhihu/main/logout/:username" , func(c *gin.Context) {//登出处理界面
		userna := c.Param("username")
		userda := Autoreaduser(userna)
		if !userda.Onionif() {
			c.HTML(200 , "loginerror.html" , gin.H{
				"what" : "用户名不存在或者用户未登陆",
			})
		} else {
			userda.putdatabase(0)
			c.Writer.WriteString("登出成功")
		}
	})
	r.GET("zhihu/main" , func(c *gin.Context) {//注册登录主界面
		c.HTML(200 , "main.html" , nil)
	})
	r.GET("zhihu/register" , func(c *gin.Context) {//注册界面
		c.HTML(200 , "register.html" , nil)
	})
	r.GET("zhihu/login" , func(c *gin.Context) {//登录界面
		c.HTML(200 , "login.html" , nil)
	})
	r.GET("zhihu/home/:username" , func(c *gin.Context) {//用户主界面
		userna := c.Param("username")
		var userda UsersDate
		userda = Autoreaduser(userna)
		if userda.Onion != 1{
			c.HTML(200 , "loginerror.html" , gin.H{
				"what" : "用户名不存在或者用户未登陆",
			})
		} else {
			var post Postdate
			count := CountAny(post)
			for i := 1 ; i<=count;i++{
				postx := Autoreanpost(i)
				replys , countreply := Autofindreply(i)
				fmt.Println(replys , countreply)
				c.HTML(200 , "postscan.html" ,gin.H{
						"replyname" : userda.UserName,
						"postid" : postx.ID,
						"username" : postx.Owner,
						"con" : postx.Postcontext,
					})
			}
			c.HTML(200 , "posting.html" , gin.H{
				"username" : userda.UserName,
			})
		}
	})

	r.POST("zhihu/home/post/:username" , func(c *gin.Context) {//发帖处理并返回
		userna := c.Param("username")
		text := c.PostForm("Context")
		userda := Autoreaduser(userna)
		if userda.Onion != 1{
			c.HTML(200 , "loginerror.html" , nil)
		} else {
			var postxx PosterandPost
			postxx.name = userda.UserName
			postxx.connect = text
			userda.putdatabase(postxx)
			c.HTML(200 , "postsuc.html" ,gin.H{
				"what" : "发帖",
				"username" : userda.UserName,
			})
		}

	})

	r.GET("zhihu/home/reply/:username" , func(c *gin.Context){ //帖子评论主界面

		userna := c.Param("username")
		postidstr := c.Query("postid")
		postid , err :=strconv.Atoi(postidstr)
		if err!= nil{
			panic(err.Error())
		}
		userda := Autoreaduser(userna)

		c.HTML(200 , "reply.html" ,gin.H{
			"username": userda.UserName,
			"postid" : postid,
		})
	})
	r.POST("zhihu/home/reply/datachange/:username" , func(c *gin.Context) {//帖子评论处理并返回
		userna := c.Param("username")
		postidstr := c.Query("postid")
		context := c.PostForm("context")
		postid , err :=strconv.Atoi(postidstr)
		if err!= nil{
			panic(err.Error())
		}
		var replyx reply
		userda := Autoreaduser(userna)
		replyx.Replyer = userda.UserName
		replyx.Bereplypostid = uint(postid)
		replyx.Context = context
		userda.putdatabase(replyx)
		c.HTML(200 ,"postsuc.html" , gin.H{
			"what" : "回复",
			"username" : userda.UserName,
		})

	})

	r.GET("zhihu/home/reply/scan/:username" , func(c *gin.Context) {//谁看那条帖子的评论
		userda := Autoreaduser(c.Param("username"))
		if userda.Onion != 1{
			c.HTML(200 , "loginerror.html" , gin.H{
				"what" : "用户名不存在或者用户未登陆",
			})
		} else {postidstr := c.Query("postid")
			postid , err := strconv.Atoi(postidstr)
			if err!= nil{
				panic(err.Error())
			}
			var replyx []reply
			replyx ,count := Autofindreply(postid)
			if count==0{
				c.HTML(200 , "noreply.html" , gin.H{
					"username" : userda.UserName,
				})
			} else {
				for i:= 0 ;i<count;i++{
					c.HTML(200 , "replyscan.html" , gin.H{
						"i" : i+1,
						"replyer" : replyx[i].Replyer,
						"con" : replyx[i].Context,
					})
				}
			}
		}
	})
	r.POST("zhihu/register" , Register)
	r.POST("zhihu/login" , login)

	r.Run(":8090")
}
